
eCommerce Web App -> DIX-STORE
====================

Using React Js
---------------------

DEMO ---->
---------------------

![image](https://github.com/thakordixit567/DIX-STORE/blob/master/DIX-STORE-PRO/src/DEMO/Screenshot%20(201).png)

![image](https://github.com/thakordixit567/DIX-STORE/blob/master/DIX-STORE-PRO/src/DEMO/Screenshot%20(203).png)

How to clone this peoject in your machine 

 ```sh
 cd your peoject name
git clone link of this peoject
```
