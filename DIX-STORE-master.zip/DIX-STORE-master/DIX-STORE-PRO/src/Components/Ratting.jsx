import React from 'react'

const Ratting = () => {
  return (
    <span>
      <i className="icofont-ui-rating"></i>
      <i className="icofont-ui-rating"></i>
      <i className="icofont-ui-rating"></i>
      <i className="icofont-ui-rating"></i>
      <i className="icofont-ui-rating"></i>
    </span>
  )
}

export default Ratting
