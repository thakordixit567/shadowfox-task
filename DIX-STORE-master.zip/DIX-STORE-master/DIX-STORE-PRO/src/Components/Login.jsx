import React from 'react'

const Login = () => {
  return (
    <div>
      <div className='m-5 p-5'>
     <button className='bg-primary px-4 text-white' onClick={handlelogin}> Login</button>
    </div>
    </div>
  )
}

export default Login
